#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/flappy"
TARGET_ROOT="$HOME/codex_flappy"
TARGET_DIR="$TARGET_ROOT/flappy"
BACKUP_DIR="$TARGET_ROOT/flappy_backup_$(date +%Y%m%d_%H%M%S)"
TEMP_VENV="$TARGET_ROOT/.flappy_preserved_venv_$$"

if [ ! -f "$SOURCE_DIR/flappy_inspector.py" ]; then
  echo "Installer source is missing flappy_inspector.py"
  exit 1
fi

mkdir -p "$TARGET_ROOT"

if [ -d "$TARGET_DIR/.venv" ]; then
  mv "$TARGET_DIR/.venv" "$TEMP_VENV"
fi

if [ -d "$TARGET_DIR" ]; then
  mv "$TARGET_DIR" "$BACKUP_DIR"
  echo "Previous simulator backed up to $BACKUP_DIR"
fi

mkdir -p "$TARGET_DIR"
cp -a "$SOURCE_DIR/." "$TARGET_DIR/"

cd "$TARGET_DIR"

if [ -d "$TEMP_VENV" ]; then
  mv "$TEMP_VENV" "$TARGET_DIR/.venv"
  echo "Preserved existing Python virtual environment."
else
  PYTHON_BIN="${PYTHON_BIN:-python3.8}"
  if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    PYTHON_BIN="python3"
  fi
  "$PYTHON_BIN" -m venv .venv
  . .venv/bin/activate
  python -m pip install --upgrade pip setuptools wheel
  python -m pip install numpy gym==0.21.0 click pydart2 || true
  python -m pip install -e . --no-deps || true
fi

chmod +x "$TARGET_DIR/start_flappy_inspector.sh"
echo "Installed bee-shell physical simulator to $TARGET_DIR"
echo "Launch URL: http://127.0.0.1:8099/?fresh=bee-shell-rotated"

