@echo off
setlocal

for /f "delims=" %%I in ('wsl.exe -d Ubuntu -- wslpath -a "%~dp0"') do set "WSL_DIR=%%I"
if "%WSL_DIR%"=="" (
  echo Could not resolve installer path inside WSL.
  pause
  exit /b 1
)

wsl.exe -d Ubuntu -- bash -lc "cd ""%WSL_DIR%"" && chmod +x start_physical_sim.sh && ./start_physical_sim.sh"
if errorlevel 1 (
  echo Physical simulator start failed.
  pause
  exit /b 1
)

start "" "http://127.0.0.1:8099/?fresh=bee-shell-rotated"

