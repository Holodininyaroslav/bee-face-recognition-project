#!/usr/bin/env bash
set -euo pipefail

TARGET_DIR="$HOME/codex_flappy/flappy"

if [ ! -f "$TARGET_DIR/flappy_inspector.py" ]; then
  echo "Physical simulator is not installed at $TARGET_DIR"
  echo "Run ./install_wsl.sh first."
  exit 1
fi

cd "$TARGET_DIR"
chmod +x start_flappy_inspector.sh
FLAPPY_INSPECTOR_PORT="${FLAPPY_INSPECTOR_PORT:-8099}" ./start_flappy_inspector.sh
echo "Open: http://127.0.0.1:${FLAPPY_INSPECTOR_PORT:-8099}/?fresh=bee-shell-rotated"
