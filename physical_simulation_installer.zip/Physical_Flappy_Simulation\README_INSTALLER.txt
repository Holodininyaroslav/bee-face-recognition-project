Bee physical simulation installer

This package installs the current local physical simulator used by the Bee Face recognition project.
It is the WSL Flappy/FWMAV inspector version with the visible bee-shell outline and live mechanics state, not the old simple canvas math demo.

Main local URL after launch:
http://127.0.0.1:8099/?fresh=bee-shell-rotated

How to run on Windows:
1. Make sure Ubuntu WSL is installed.
2. Run install_and_run_wsl.bat.
3. The installer copies this version to ~/codex_flappy/flappy inside WSL.
4. It preserves an existing ~/codex_flappy/flappy/.venv when present, so an already working simulator keeps its known-good dependencies.

Manual WSL run:
cd /path/to/Physical_Flappy_Simulation
chmod +x install_wsl.sh start_physical_sim.sh
./install_wsl.sh
./start_physical_sim.sh
